package com.crs.dao;

import com.crs.pojos.People;

public interface PeopleDAO {
    public People save(People people);
}