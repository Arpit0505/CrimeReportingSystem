package com.crs.service;

import com.crs.pojos.People;

public interface PeopleService {

    public People addSinglePeopleDetail(People people);

}